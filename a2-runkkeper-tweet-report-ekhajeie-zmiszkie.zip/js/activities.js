function parseTweets(runkeeper_tweets) 
{
	//Do not proceed if no tweets loaded
	if(runkeeper_tweets === undefined) 
	{
		window.alert('No tweets returned');
		return;
	}
	
	tweet_array = runkeeper_tweets.map(function(tweet) {
		return new Tweet(tweet.text, tweet.created_at);
	});

	const act_dict = {}
	let longest_activity_type = null;
	let shortest_activity_type = null;
	/* Block of code to sort through the longest and shortest activity types and parsing through each tweet. Also I create blocks of code to 
	parse through each activity and add the count and the distance to be able to use this in my graphs, I append these to a dictionary.*/
	for (const each_tweet of tweet_array)
	{
		const act_type = each_tweet.activityType;
		const distance = each_tweet.distance;

		if (act_dict.hasOwnProperty(act_type) == false)
		{
			act_dict[act_type] = {count: 1, total_distance: distance};
		}
		else
		{
			act_dict[act_type].count++;
			act_dict[act_type].total_distance += distance;
		}

		if (!longest_activity_type || act_dict[act_type].total_distance > act_dict[longest_activity_type].total_distance) 
		{
			longest_activity_type = act_type;
		}
	
		if ((!shortest_activity_type || act_dict[act_type].total_distance < act_dict[shortest_activity_type].total_distance) &&
			act_type !== 'unknown' && act_type !== 'Non-distance workouts' && act_dict[act_type].total_distance !== 0)
		{
			shortest_activity_type = act_type;
		}
	}

	/*This section of code counts the weekends and the weekdays to make sure that I get these values correctly for the weekends and weekdays */
	let totalDistanceWeekdays = 0;
	let totalDistanceWeekends = 0;
	let countWeekdays = 0;
	let countWeekends = 0;

	const is_a_weekend = (date) => 
	{
		const day = date.getDay();
		return day == 0 || day == 6;
	};

	for (const each_tweet of tweet_array) 
	{
		const distance = each_tweet.distance;
		const tweetDate = each_tweet.time;
	
		if (distance > 0 && distance !== null) 
		{
			if (is_a_weekend(tweetDate))
			{
				totalDistanceWeekends += distance;
				countWeekends++;
			} 
			else 
			{
				totalDistanceWeekdays += distance;
				countWeekdays++;
			}
		}
	}
	

	for (const key in act_dict) {
		if (act_dict.hasOwnProperty(key)) 
		{
			const trimmedKey = key.trim();
			if (trimmedKey !== key) {
				act_dict[trimmedKey] = act_dict[key];
				delete act_dict[key];
			}
		}
	}

	/*This section checks to make sure wheter the weekdays or weekend count is greater */
	var actArray = Object.entries(act_dict);
	actArray.sort((a, b) => b[1].count - a[1].count);
	var top3 = actArray.slice(0, 3);
	var top3Dict = Object.fromEntries(top3);
	
		var countComparison;
	if (countWeekends > countWeekdays) 
	{
		countComparison = "Weekends";
	}
	else if (countWeekends < countWeekdays) 
	{
		countComparison = "Weekdays";
	}
	else 
	{
		countComparison = "Weekends and Weekdays";
	}
	// Log the top 3 entries
	//TODO: create a new array or manipulate tweet_array to create a graph of the number of tweets containing each type of activity.*/
	const total = ['run ', 'bike ', 'swim ', 'walk ', 'activity ','hike ','skate ','snowboard ','row ','chair ride ', 'elliptical workout', 'circuit workout', 'mysports freestyle', 'crossfit','mysports gym','barre workout','bootcamp workout','boxing','Core Workout','Dance','Group Workout','Meditation','Yoga','Pilates','Spinning Workout','Sports','Stairmaster / Stepwell Workout','Strength Workout' ]

	var keys = Object.keys(top3Dict);

	// Sort the keys based on the count in descending order
	keys.sort(function(a, b) {
		return top3Dict[b].count - top3Dict[a].count;
	});
	
	// Extract the top 3 keys
	var firstTopKey = keys[0];
	var secondTopKey = keys[1];
	var thirdTopKey = keys[2];
	
	/* Below is the section for the graphs, we use the JS methods as opposed ot Jquery to update the span for the elements. 
	We also use the data that was given to use to parse through and add these values to the dynamic graphs*/
	document.getElementById("numberActivities").innerText = total.length;
	document.getElementById("firstMost").innerText = firstTopKey;
	document.getElementById("secondMost").innerText = secondTopKey;
	document.getElementById("thirdMost").innerText = thirdTopKey;
	document.getElementById("longestActivityType").innerText = longest_activity_type;
	document.getElementById("shortestActivityType").innerText = shortest_activity_type;
	document.getElementById("weekdayOrWeekendLonger").innerText = countComparison;
	activity_vis_spec = 
	{
		"$schema": "https://vega.github.io/schema/vega-lite/v5.json",
		"description": "A graph of the number of Tweets containing each type of activity.",
		"data": {
		  "values": Object.entries(act_dict).map(([activityType, { count }]) => ({ activityType, count }))
		},
		"mark": "bar",
		"encoding": {
		  "x": {"field": "activityType", "type": "nominal"},
		  "y": {"field": "count", "type": "quantitative"}
		}
	  };
	vegaEmbed('#activityVis', activity_vis_spec, {actions:false});

	
	const top3Activities = Object.keys(top3Dict);
	const aggregatedData = [];

	for (const activity of top3Activities) 
	{
	const distancesByDayOfWeek = {};
	for (const tweet of tweet_array) 
	{
		if (tweet.activityType === activity)
		{
		const timestamp = new Date(tweet.time);
		const dayOfWeek = timestamp.getDay();
		//console.log(dayOfWeek) -> works
		const lowercaseText = tweet.text.toLowerCase();
		const activityType = tweet.getActivityType;
		const distance = tweet.distance;

		if (!distancesByDayOfWeek[dayOfWeek]) 
		{
			distancesByDayOfWeek[dayOfWeek] = [];
		}

		distancesByDayOfWeek[dayOfWeek].push(tweet.distance);
		}
		}
		aggregatedData.push({ activity, distancesByDayOfWeek }); 
		//console.log(aggregatedData)
	}
	
	const distance_by_day_of_week_mean = {};
	aggregatedData.forEach(({ activity, distancesByDayOfWeek }) => {
		Object.entries(distancesByDayOfWeek).forEach(([dayOfWeek, distances]) => 
		{
			const dayOfWeekNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
			const dayName = dayOfWeekNames[+dayOfWeek];
			const meanDistance = distances.reduce((sum, distance) => sum + distance, 0) / distances.length;
			if (!distance_by_day_of_week_mean[dayName]) {
				distance_by_day_of_week_mean[dayName] = [];
			}
			distance_by_day_of_week_mean[dayName].push(meanDistance);
		});
	});
	
	// all activities
	distance_vis_spec = {
		"$schema": "https://vega.github.io/schema/vega-lite/v5.json",
		"description": "A graph of the distance of each type of activity.",
		"data": {
		  "values": aggregatedData.reduce((acc, { activity, distancesByDayOfWeek }) => {
			// Iterate over each day of the week and its distances for the current activity
			Object.entries(distancesByDayOfWeek).forEach(([dayOfWeek, distances]) => {
			  // Convert dayOfWeek to name
			  const dayOfWeekNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
			  const dayName = dayOfWeekNames[+dayOfWeek];
			  
			  // Create a separate data point for each distance
			  distances.forEach(distance => {
				acc.push(
					{
				  "activityType": activity,
				  "time (day)": dayName,
				  "distance": distance
				});
			  });
			});
			return acc;
		  }, [])
		},
		"mark": "point",

		"encoding": {
		  "x": {"field": "time (day)", "type": "nominal", "sort": ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']},
		  "y": {"field": "distance", "type": "quantitative"},
		  "color": {"field": "activityType", "type": "nominal"}
		}
	  };
	  
	  vegaEmbed('#distanceVis', distance_vis_spec, { actions: false });

	// means
	distance_vis_aggregated_spec = 
	{
		"$schema": "https://vega.github.io/schema/vega-lite/v5.json",
		"description": "A graph of the mean distance of each type of activity.",
		"data": {
			"values": aggregatedData.reduce((acc, { activity, distancesByDayOfWeek }) => {
			  // Iterate over each day of the week and its distances for the current activity
			  Object.entries(distancesByDayOfWeek).forEach(([dayOfWeek, distances]) => {
				// Convert dayOfWeek to name
				const dayOfWeekNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
				const dayName = dayOfWeekNames[+dayOfWeek];
				
				// Calculate the mean distance for each day
				const meanDistance = distances.reduce((sum, distance) => sum + distance, 0) / distances.length;
		
				// Push the mean distance as a data point
				acc.push({
				  "activityType": activity,
				  "time (day)": dayName,
				  "mean of distance": meanDistance
				});
			  });
			  return acc;
			}, [])
		  },
		  "mark": "point",
		  "encoding": {
			"x": {"field": "time (day)", "type": "nominal", "sort": ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']},
			"y": {"field": "mean of distance", "type": "quantitative"},
			"color": {"field": "activityType", "type": "nominal"}
		  }
	  };
	vegaEmbed('#distanceVisAggregated', distance_vis_aggregated_spec, {actions:false});
	var distanceVisAggregatedContainer = document.getElementById('distanceVisAggregated');
	var distanceVisContainer = document.getElementById('distanceVis');
	distanceVisContainer.style.display = 'block';
	distanceVisAggregatedContainer.style.display = 'none';

	document.getElementById('aggregate').addEventListener('click', toggleGraphs);
	}

function toggleGraphs() {
	// use the buttons to make toggle between the graphs.
	var distanceVisContainer = document.getElementById('distanceVis');
	var distanceVisAggregatedContainer = document.getElementById('distanceVisAggregated');

	// Toggle the display property of the containers
	if (distanceVisContainer.style.display === 'none') {
		document.getElementById('aggregate').innerText = "Show means";
		distanceVisContainer.style.display = 'block';
		distanceVisAggregatedContainer.style.display = 'none';
	} else {
		document.getElementById('aggregate').innerText = "Show all activities";
		distanceVisContainer.style.display = 'none';
		distanceVisAggregatedContainer.style.display = 'block';
	}
}
	//TODO: create the visualizations which group the three most-tweeted activities by the day of the week.
	//Use those visualizations to answer the questions about which activities tended to be longest and when.

//Wait for the DOM to load
document.addEventListener('DOMContentLoaded', function (event) {
	loadSavedRunkeeperTweets().then(parseTweets).then();
});
