function parseTweets(runkeeper_tweets) 
{
	//Do not proceed if no tweets loaded
	if(runkeeper_tweets === undefined) {
		window.alert('No tweets returned');
		return;
	}

	tweet_array = runkeeper_tweets.map(function(tweet) {
		return new Tweet(tweet.text, tweet.created_at);
	});



	earliest_tweet = function(tweet_array) 
	// gets earliest tweet
	{
		let earliest = tweet_array[0];
	
		for (let i = 1; i < tweet_array.length; i++) {
			if (tweet_array[i].time < earliest.time) {
				earliest = tweet_array[i];
			}
		}
	
		return earliest;
	};

	latest_tweet = function(tweet_array) {
	// gets latest function
		let latest = tweet_array[0];
	
		for (let i = 1; i < tweet_array.length; i++) {
			if (tweet_array[i].time > latest.time) {
				latest = tweet_array[i];
			}
		}
	
		return latest;
	};

	completed_events = function(tweet_array) {
	// returns amount of completed events
		amount = 0;
		
		for (let i = 0; i < tweet_array.length; i++) {
			if (tweet_array[i].source === "completed_event") {
				amount++;
			}
		}
		return amount
	};

	live_events = function(tweet_array) {
	// returns amount of live_events
		amount = 0;
		
		for (let i = 0; i < tweet_array.length; i++) {
			if (tweet_array[i].source === "live_event") {
				amount++;
			}
		}
		return amount
	};

	achievements = function(tweet_array) {
	// returns amount achievements
		amount = 0;
		
		for (let i = 0; i < tweet_array.length; i++) {
			if (tweet_array[i].source === "achievement") {
				amount++;
			}
		}
		return amount
	};


	miscellaneous = function(tweet_array)
	// returns misc amount
	 {
		amount = 0;
		
		for (let i = 0; i < tweet_array.length; i++) {
			if (tweet_array[i].source === "miscellaneous") {
				amount++;
			}
		}
		return amount
	};

	written_text = function(tweet_array) {
	// returns amount of written text tweets
		amount = 0;

		for (let i = 0; i < tweet_array.length; i++) {
			if (tweet_array[i].writtenText != ""){
				amount++;
			}
		}
		return amount;
	}

	const options = {
		weekday: "long",
		year: "numeric",
		day: "2-digit",
		month: "long",
	};

	//This line modifies the DOM, searching for the tag with the numberTweets ID and updating the text.
	//It works correctly, your task is to update the text of the other tags in the HTML file!
	document.getElementById('numberTweets').innerText = tweet_array.length;
    document.getElementById('firstDate').innerText = earliest_tweet(tweet_array).time.toLocaleDateString("en-US", options);
	document.getElementById('lastDate').innerText = latest_tweet(tweet_array).time.toLocaleDateString("en-US", options);
	// Completed
	document.getElementsByClassName('completedEvents')[0].innerHTML = completed_events(tweet_array);
	document.getElementsByClassName('completedEvents')[1].innerHTML = completed_events(tweet_array);
	document.getElementsByClassName('completedEventsPct')[0].innerHTML = (completed_events(tweet_array) / tweet_array.length * 100).toFixed(2) + "%";
	// Live Events
	document.getElementsByClassName('liveEvents')[0].innerHTML = live_events(tweet_array);
	document.getElementsByClassName('liveEventsPct')[0].innerHTML = (live_events(tweet_array) / tweet_array.length * 100).toFixed(2) + "%";
	// achievements
	document.getElementsByClassName('achievements')[0].innerHTML = achievements(tweet_array);
	document.getElementsByClassName('achievementsPct')[0].innerHTML = (achievements(tweet_array) / tweet_array.length * 100).toFixed(2) + "%";
	//Miscellaneous
	document.getElementsByClassName('miscellaneous')[0].innerHTML = miscellaneous(tweet_array);
	document.getElementsByClassName('miscellaneousPct')[0].innerHTML = (miscellaneous(tweet_array) / tweet_array.length * 100).toFixed(2) + "%";
	// amount of completed tweets and written events
	document.getElementsByClassName('written')[0].innerHTML = written_text(tweet_array);
	document.getElementsByClassName('writtenPct')[0].innerHTML = (written_text(tweet_array) / completed_events(tweet_array) * 100).toFixed(2) + "%";

	
}

//Wait for the DOM to load
document.addEventListener('DOMContentLoaded', function (event) {
	loadSavedRunkeeperTweets().then(parseTweets);
});