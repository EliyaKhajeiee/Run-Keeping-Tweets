function parseTweets(runkeeper_tweets) {
	//Do not proceed if no tweets loaded
	if(runkeeper_tweets === undefined) {
		window.alert('No tweets returned');
		return;
	}

	//TODO: Filter to just the written tweets
	tweet_array = runkeeper_tweets.map(function(tweet) {
		return new Tweet(tweet.text, tweet.created_at);
	});
	for (let i = tweet_array.length - 1; i >= 0; i--) {
		// Replace the condition below with your own condition
		if (tweet_array[i].writtenText == "") {
			tweet_array.splice(i, 1); // Remove the element at index i
		}
	}
	document.getElementById('searchCount').innerText = 0;
	document.getElementById('searchText').innerText = '';
}

function addEventHandlerForSearch() {
	//TODO: Search the written tweets as text is entered into the search box, and add them to the table
	var text_search = document.getElementById('textFilter');
	text_search.addEventListener("input", function(event) {
		// This function will be called whenever the text in the text box changes
		var table = document.getElementById('tweetTable');
		while (table.firstChild) {
			table.removeChild(table.firstChild);
		}
		var writtenText = event.target.value;
		if (writtenText == "") {
			document.getElementById('searchCount').innerText = 0;
			document.getElementById('searchText').innerText = writtenText;
		} else {
			var count = 0;
			
			for (let i = 0; i < tweet_array.length; i++){
				// append each row with number, tweet text, and activity type
				if (tweet_array[i].writtenText.includes(writtenText)) {
					count++;
					var newRow = document.createElement('tr');
					
					var indexCell = document.createElement('th');
					indexCell.textContent = table.children.length + 1;
					newRow.appendChild(indexCell);

					var activityTypeCell = document.createElement('td');
					activityTypeCell.textContent = tweet_array[i].activityType; // Assuming tweet has an activityType property
					newRow.appendChild(activityTypeCell);

					var tweetCell = document.createElement('td');
					tweetCell.innerHTML = tweet_array[i].getHTMLTableRow(i + 1); // Assuming tweet has a text property
					newRow.appendChild(tweetCell);

					table.appendChild(newRow);
				}

			}

			document.getElementById('searchCount').innerText = count;
			document.getElementById('searchText').innerText = writtenText;
			document.getElementById('searchText').innerText = writtenText;

		}
	});
}

//Wait for the DOM to load
document.addEventListener('DOMContentLoaded', function (event) {
	addEventHandlerForSearch();
	loadSavedRunkeeperTweets().then(parseTweets);
});