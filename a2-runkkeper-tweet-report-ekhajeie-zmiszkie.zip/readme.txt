--Readme document for *author*--

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

20/20
- 2/2 Tweet dates
- 3/3 Tweet categories
- 3/3 User-written tweets
- 3/3 Determining activity type and distance
- 3/3 Graphing activities by distance
- 3/3 Implementing the search box
- 3/3 Populating the table

2. How long, in hours, did it take you to complete this assignment?
It took us around 15 hours to complete.


3. What online resources did you consult when completing this assignment? (list sites like StackOverflow or specific URLs for tutorials, etc.)
We used websites like StackOverflow, W3Schools.com, tutorialspoint, and geeksforgeeks.com


4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?
We did not consult with other classmates other than through the use of slack.


5. Is there anything special we need to know in order to run your code?
No, the code should run just fine with something like live preview.
